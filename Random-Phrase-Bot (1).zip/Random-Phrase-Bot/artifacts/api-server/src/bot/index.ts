import TelegramBot, { type Message, type CallbackQuery } from "node-telegram-bot-api";
import { logger } from "../lib/logger.js";
import {
  getData, addPhrase, deletePhrase, listPhrases, clearCategory,
  recordMessage, getStats, getTodayLog, clearStats,
  setOwnerChatId, getOwnerChatId,
  isBlocked, blockUser, unblockUser, warnUser, unwarnUser, clearWarnings, getBlockedList,
  getSpecialUsers, getSpecialUser, addSpecialUser, removeSpecialUser,
  addSpecialPhrase, deleteSpecialPhrase, clearSpecialPhrases,
  MAX_WARNINGS,
  type Category, type UserCategory,
} from "./store.js";

const OWNER_USERNAME = "MVRABLEH";

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
function isOwner(msg: Message): boolean {
  return msg.from?.username === OWNER_USERNAME;
}
function isOwnerQuery(q: CallbackQuery): boolean {
  return q.from?.username === OWNER_USERNAME;
}
function formatList(items: string[]): string {
  if (items.length === 0) return "Список пуст.";
  return items.map((t, i) => `${i + 1}. ${t}`).join("\n");
}
function scheduleDailySummary(fn: () => void): void {
  const now = new Date();
  const msk = new Date(now.toLocaleString("en-US", { timeZone: "Europe/Moscow" }));
  const next = new Date(msk); next.setHours(24, 0, 0, 0);
  setTimeout(() => { fn(); setInterval(fn, 86_400_000); }, next.getTime() - msk.getTime());
}

// ── Gift system ───────────────────────────────────────────────────────────────

const GIFT_CATEGORIES = [
  { code: "flowers",  emoji: "🌸", label: "Цветы"      },
  { code: "sweets",   emoji: "🍬", label: "Сладость"   },
  { code: "card",     emoji: "💌", label: "Открытка"   },
  { code: "jewelry",  emoji: "💎", label: "Украшение"  },
  { code: "trinkets", emoji: "🎀", label: "Безделушка" },
] as const;

type GiftCatCode = "flowers" | "sweets" | "card" | "jewelry" | "trinkets";

const GIFT_ITEMS: Record<Exclude<GiftCatCode, "card">, string[]> = {
  flowers:  ["Тюльпаны 🌷", "Астры 💮", "Розы 🌹", "Ромашки 🌼", "Васильки 💐", "Орхидея 🌺", "Лилии 🤍"],
  sweets:   ["Булочка 🥐", "Тортик 🎂", "Коробка конфет 🍫", "Мешочек мармелада 🍬", "Восточная сладость ✨"],
  jewelry:  ["Серьги 💎", "Ожерелье 📿", "Кольцо 💍", "Кулон 🔮", "Браслет ✨"],
  trinkets: ["Деревянная игрушка 🪀", "Брелок 🗝", "Заколка 🪷", "Гребешок 🌙", "Крабик 🦀"],
};

const GIFT_EMOJI: Record<Exclude<GiftCatCode, "card">, string> = {
  flowers: "🌸", sweets: "🍬", jewelry: "💎", trinkets: "🎀",
};

function giftMainKeyboard(isAnon: boolean) {
  return {
    inline_keyboard: [
      ...GIFT_CATEGORIES.map((c) => ([
        { text: `${c.emoji} ${c.label}`, callback_data: `gcat_${c.code}` },
      ])),
      [{ text: isAnon ? "🎭 Анонимно: вкл" : "👤 Анонимно: выкл", callback_data: "ganon" }],
    ],
  };
}

function giftItemKeyboard(cat: Exclude<GiftCatCode, "card">) {
  const items = GIFT_ITEMS[cat];
  return {
    inline_keyboard: [
      ...items.map((item, i) => ([{ text: item, callback_data: `gitem_${cat}_${i}` }])),
      [{ text: "◀ Назад", callback_data: "gback" }],
    ],
  };
}

// ── Special users inline menu ─────────────────────────────────────────────────

type CatCode = "f" | "g" | "s";
const CAT_LABEL: Record<CatCode, string> = { f: "📝 Фразы", g: "💬 Сплетни", s: "🤫 Секреты" };
const CAT_KEY: Record<CatCode, UserCategory> = { f: "phrases", g: "gossips", s: "secrets" };

function usersMenuKeyboard() {
  const users = Object.values(getSpecialUsers());
  const rows = users.map((u) => [{ text: `⭐ @${u.username}`, callback_data: `u_${u.username}` }]);
  return { inline_keyboard: rows };
}

function userMenuKeyboard(username: string) {
  const user = getSpecialUser(username);
  if (!user) return { inline_keyboard: [] };
  return {
    inline_keyboard: [
      [{ text: `📝 Фразы (${user.phrases.length})`, callback_data: `f_${username}` }],
      [{ text: `💬 Сплетни (${user.gossips.length})`, callback_data: `g_${username}` }],
      [{ text: `🤫 Секреты (${user.secrets.length})`, callback_data: `s_${username}` }],
      [{ text: "🗑 Удалить этого пользователя", callback_data: `del_${username}` }],
      [{ text: "◀ Назад", callback_data: "back" }],
    ],
  };
}

function categoryMenuKeyboard(username: string, cat: CatCode) {
  return {
    inline_keyboard: [
      [{ text: "➕ Добавить", callback_data: `a${cat}_${username}` }],
      [{ text: "🗑 Очистить всё", callback_data: `c${cat}_${username}` }],
      [{ text: "◀ Назад к пользователю", callback_data: `u_${username}` }],
    ],
  };
}

function renderCategoryText(username: string, cat: CatCode): string {
  const user = getSpecialUser(username);
  if (!user) return "Пользователь не найден.";
  const items = user[CAT_KEY[cat]];
  const label = CAT_LABEL[cat];
  if (items.length === 0)
    return `⭐ @${username} — ${label}\n\nСписок пуст. Нажми ➕ чтобы добавить.`;
  return `⭐ @${username} — ${label} (${items.length}):\n\n${items.map((t, i) => `${i + 1}. ${t}`).join("\n")}`;
}

let _botRunning = false;
let _botStartedAt: string | null = null;

export function getBotStatus(): { running: boolean; startedAt: string | null } {
  return { running: _botRunning, startedAt: _botStartedAt };
}

export function startBot(): void {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) { logger.warn("TELEGRAM_BOT_TOKEN not set — bot will not start"); return; }

  const bot = new TelegramBot(token, { polling: true });
  _botRunning = true;
  _botStartedAt = new Date().toISOString();
  logger.info("Telegram bot started");

  const replyMap = new Map<number, number>();
  const spamTracker = new Map<number, { lastText: string; count: number; lastTime: number }>();
  const SPAM_WINDOW_MS = 10_000;

  // Admin: awaiting phrase text from inline menu
  type AwaitState = { username: string; cat: CatCode; chatId: number; menuMsgId: number };
  let awaitState: AwaitState | null = null;

  // Gift: users who chose anonymous mode (chatId set)
  const anonGift = new Set<number>();

  // Gift: awaiting card text from user (chatId → { menuMsgId, isAnon })
  const giftCardAwait = new Map<number, { menuMsgId: number; isAnon: boolean }>();

  // Gift: stored card texts for owner "read" button (cardId → { text, senderName })
  let cardCounter = 0;
  const cardStore = new Map<number, { text: string; senderName: string }>();

  // ── Daily summary ─────────────────────────────────────────────────

  scheduleDailySummary(() => {
    const id = getOwnerChatId(); if (!id) return;
    const s = getStats();
    bot.sendMessage(id,
      `🌙 *Итоги дня:*\n\nСообщений: ${s.today}\nВсего: ${s.total}`,
      { parse_mode: "Markdown" }
    ).catch(() => {});
  });

  // ── Public commands ───────────────────────────────────────────────

  bot.onText(/\/start/, (msg) => {
    if (isOwner(msg)) setOwnerChatId(msg.chat.id);
    bot.sendMessage(msg.chat.id,
      "Привет! Вот что я умею:\n\n" +
      "/random — рандомная фраза персонажа\n" +
      "/gossip — одна сплетня\n" +
      "/tellsecret — один секрет\n" +
      "/gift — сделать подарок\n\n" +
      "Или просто напиши мне что-нибудь — я передам это анонимно."
    );
  });

  bot.onText(/\/random/, (msg) => {
    const uname = msg.from?.username;
    const special = uname ? getSpecialUser(uname) : null;
    const pool = special && special.phrases.length > 0 ? special.phrases : getData().randomPhrases;
    if (pool.length === 0) { bot.sendMessage(msg.chat.id, "Фраз пока нет."); return; }
    bot.sendMessage(msg.chat.id, pick(pool));
  });

  bot.onText(/\/gossip/, (msg) => {
    const uname = msg.from?.username;
    const special = uname ? getSpecialUser(uname) : null;
    const pool = special && special.gossips.length > 0 ? special.gossips : getData().gossips;
    if (pool.length === 0) { bot.sendMessage(msg.chat.id, "Сплетен пока нет."); return; }
    bot.sendMessage(msg.chat.id, pick(pool));
  });

  bot.onText(/\/tellsecret/, (msg) => {
    const uname = msg.from?.username;
    const special = uname ? getSpecialUser(uname) : null;
    const pool = special && special.secrets.length > 0 ? special.secrets : getData().secrets;
    if (pool.length === 0) { bot.sendMessage(msg.chat.id, "Секретов пока нет."); return; }
    bot.sendMessage(msg.chat.id, pick(pool));
  });

  // ── /gift command ─────────────────────────────────────────────────

  bot.onText(/\/gift/, (msg) => {
    if (isBlocked(msg.chat.id)) {
      bot.sendMessage(msg.chat.id, "🚫 Ты заблокирован.");
      return;
    }
    const isAnon = anonGift.has(msg.chat.id);
    bot.sendMessage(msg.chat.id,
      "🎁 *Сделать подарок*\n\nВыбери категорию:",
      { parse_mode: "Markdown", reply_markup: giftMainKeyboard(isAnon) }
    );
  });

  // ── Admin: users menu ─────────────────────────────────────────────

  bot.onText(/\/users/, (msg) => {
    if (!isOwner(msg)) return;
    setOwnerChatId(msg.chat.id);
    const users = Object.values(getSpecialUsers());
    const header = users.length === 0
      ? "⭐ *Особые пользователи*\n\nСписок пуст.\n\n/adduser @username — добавить"
      : `⭐ *Особые пользователи* (${users.length}):\n\nВыбери пользователя:`;
    bot.sendMessage(msg.chat.id, header, {
      parse_mode: "Markdown",
      reply_markup: usersMenuKeyboard(),
    });
  });

  bot.onText(/\/adduser (.+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const raw = match?.[1]?.trim().replace(/^@/, "");
    if (!raw) { bot.sendMessage(msg.chat.id, "Укажи username: /adduser @username"); return; }
    const ok = addSpecialUser(raw);
    if (!ok) {
      bot.sendMessage(msg.chat.id, `ℹ️ @${raw} уже в списке.`);
    } else {
      bot.sendMessage(msg.chat.id,
        `✅ @${raw} добавлен в особые пользователи.\n\nОткрой меню через /users.`
      );
    }
  });

  // ── Callback handler ──────────────────────────────────────────────

  bot.on("callback_query", async (q) => {
    const data    = q.data ?? "";
    const chatId  = q.message?.chat.id;
    const msgId   = q.message?.message_id;

    await bot.answerCallbackQuery(q.id).catch(() => {});
    if (!chatId || !msgId) return;

    // ════════════════════════════════════════
    // GIFT callbacks — accessible to all users
    // ════════════════════════════════════════

    // Gift: toggle anon mode
    if (data === "ganon") {
      if (anonGift.has(chatId)) anonGift.delete(chatId); else anonGift.add(chatId);
      const isAnon = anonGift.has(chatId);
      await bot.editMessageText("🎁 *Сделать подарок*\n\nВыбери категорию:", {
        chat_id: chatId, message_id: msgId,
        parse_mode: "Markdown", reply_markup: giftMainKeyboard(isAnon),
      }).catch(() => {});
      return;
    }

    // Gift: back to main categories
    if (data === "gback") {
      const isAnon = anonGift.has(chatId);
      await bot.editMessageText("🎁 *Сделать подарок*\n\nВыбери категорию:", {
        chat_id: chatId, message_id: msgId,
        parse_mode: "Markdown", reply_markup: giftMainKeyboard(isAnon),
      }).catch(() => {});
      return;
    }

    // Gift: category selected
    if (data.startsWith("gcat_")) {
      const cat = data.slice(5) as GiftCatCode;

      if (cat === "card") {
        // Enter card-writing mode
        const isAnon = anonGift.has(chatId);
        giftCardAwait.set(chatId, { menuMsgId: msgId, isAnon });
        await bot.editMessageText(
          `💌 *Открытка*${isAnon ? " _(анонимно)_" : ""}\n\nНапиши текст своей открытки — следующее сообщение станет ею:`,
          { chat_id: chatId, message_id: msgId, parse_mode: "Markdown",
            reply_markup: { inline_keyboard: [[{ text: "◀ Отмена", callback_data: "gback" }]] } }
        ).catch(() => {});
        return;
      }

      const validCat = cat as Exclude<GiftCatCode, "card">;
      const catInfo = GIFT_CATEGORIES.find((c) => c.code === cat);
      await bot.editMessageText(
        `${catInfo?.emoji ?? "🎁"} *${catInfo?.label ?? cat}*\n\nЧто подарить?`,
        { chat_id: chatId, message_id: msgId,
          parse_mode: "Markdown", reply_markup: giftItemKeyboard(validCat) }
      ).catch(() => {});
      return;
    }

    // Gift: specific item selected
    if (data.startsWith("gitem_")) {
      const parts = data.split("_");
      const cat = parts[1] as Exclude<GiftCatCode, "card">;
      const idx = parseInt(parts[2] ?? "0", 10);
      const item = GIFT_ITEMS[cat]?.[idx];
      if (!item) return;

      const isAnon = anonGift.has(chatId);
      const senderName = isAnon ? "Аноним" : (q.from.username ? `@${q.from.username}` : "Аноним");
      const catLabel = GIFT_CATEGORIES.find((c) => c.code === cat)?.label ?? cat;

      // Confirm to sender
      await bot.editMessageText(
        `${GIFT_EMOJI[cat]} *Подарок отправлен!*\n\nТы подарил: ${item}`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown" }
      ).catch(() => {});

      // Notify owner (store in replyMap so owner can reply back)
      const ownerChatId = getOwnerChatId();
      if (ownerChatId) {
        try {
          const notif = await bot.sendMessage(ownerChatId,
            `🎁 *Тебе подарок!*\n\nОт: ${senderName}\nКатегория: ${catLabel}\nПодарок: ${item}\n\n_Ответь на это сообщение, чтобы написать анонимно._`,
            { parse_mode: "Markdown" }
          );
          replyMap.set(notif.message_id, chatId);
        } catch (err) { logger.error({ err }, "Failed to send gift notification"); }
      }
      return;
    }

    // Gift: owner reads a postcard
    if (data.startsWith("gread_")) {
      const cardId = parseInt(data.slice(6), 10);
      const card = cardStore.get(cardId);
      if (!card) {
        await bot.editMessageText("💌 Открытка не найдена (возможно, бот перезапускался).", {
          chat_id: chatId, message_id: msgId,
        }).catch(() => {});
        return;
      }
      await bot.editMessageText(
        `💌 *Открытка от ${card.senderName}:*\n\n${card.text}`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown" }
      ).catch(() => {});
      return;
    }

    // Gift: cancel card writing
    if (data === "gcancel") {
      giftCardAwait.delete(chatId);
      const isAnonCancel = anonGift.has(chatId);
      await bot.editMessageText("🎁 *Сделать подарок*\n\nВыбери категорию:", {
        chat_id: chatId, message_id: msgId,
        parse_mode: "Markdown", reply_markup: giftMainKeyboard(isAnonCancel),
      }).catch(() => {});
      return;
    }

    // ════════════════════════════════════════
    // ADMIN callbacks — owner only
    // ════════════════════════════════════════

    if (!isOwnerQuery(q)) return;

    // back → users list
    if (data === "back") {
      const users = Object.values(getSpecialUsers());
      const header = users.length === 0
        ? "⭐ *Особые пользователи*\n\nСписок пуст.\n\n/adduser @username — добавить"
        : `⭐ *Особые пользователи* (${users.length}):`;
      await bot.editMessageText(header, {
        chat_id: chatId, message_id: msgId,
        parse_mode: "Markdown", reply_markup: usersMenuKeyboard(),
      }).catch(() => {});
      return;
    }

    // u_USERNAME → user menu
    if (data.startsWith("u_")) {
      const username = data.slice(2);
      const user = getSpecialUser(username);
      if (!user) { bot.sendMessage(chatId, "❌ Пользователь не найден."); return; }
      await bot.editMessageText(
        `⭐ *@${username}*\n\nВыбери категорию:`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: userMenuKeyboard(username) }
      ).catch(() => {});
      return;
    }

    // del_USERNAME → remove user
    if (data.startsWith("del_")) {
      const username = data.slice(4);
      removeSpecialUser(username);
      const users = Object.values(getSpecialUsers());
      await bot.editMessageText(
        `✅ @${username} удалён.\n\n⭐ *Особые пользователи* (${users.length}):`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: usersMenuKeyboard() }
      ).catch(() => {});
      return;
    }

    // [f|g|s]_USERNAME → show category
    const catShowMatch = data.match(/^([fgs])_(.+)$/);
    if (catShowMatch) {
      const cat = catShowMatch[1] as CatCode;
      const username = catShowMatch[2];
      await bot.editMessageText(renderCategoryText(username, cat), {
        chat_id: chatId, message_id: msgId,
        reply_markup: categoryMenuKeyboard(username, cat),
      }).catch(() => {});
      return;
    }

    // a[f|g|s]_USERNAME → await add phrase
    const catAddMatch = data.match(/^a([fgs])_(.+)$/);
    if (catAddMatch) {
      const cat = catAddMatch[1] as CatCode;
      const username = catAddMatch[2];
      awaitState = { username, cat, chatId, menuMsgId: msgId };
      await bot.sendMessage(chatId,
        `✏️ Введи текст для *${CAT_LABEL[cat]}* (@${username}):\n\n_Следующее твоё сообщение будет добавлено._`,
        { parse_mode: "Markdown" }
      ).catch(() => {});
      return;
    }

    // c[f|g|s]_USERNAME → clear category
    const catClearMatch = data.match(/^c([fgs])_(.+)$/);
    if (catClearMatch) {
      const cat = catClearMatch[1] as CatCode;
      const username = catClearMatch[2];
      clearSpecialPhrases(username, CAT_KEY[cat]);
      await bot.editMessageText(renderCategoryText(username, cat), {
        chat_id: chatId, message_id: msgId,
        reply_markup: categoryMenuKeyboard(username, cat),
      }).catch(() => {});
      return;
    }
  });

  // ── Admin phrase management ───────────────────────────────────────

  bot.onText(/\/adminhelp/, (msg) => {
    if (!isOwner(msg)) return;
    setOwnerChatId(msg.chat.id);
    bot.sendMessage(msg.chat.id,
      "🔧 *Команды администратора:*\n\n" +
      "*Особые пользователи:*\n" +
      "/users — меню пользователей\n" +
      "/adduser @username — добавить пользователя\n\n" +
      "*Обычные фразы:*\n" +
      "/listphrases · /addphrase текст · /deletephrase N · /clearphrases\n\n" +
      "*Сплетни:*\n" +
      "/listgossips · /addgossip текст · /deletegossip N · /cleargossips\n\n" +
      "*Секреты:*\n" +
      "/listsecrets · /addsecret текст · /deletesecret N · /clearsecrets\n\n" +
      "*Модерация* (ответом на сообщение):\n" +
      "/warn · /unwarn · /block · /unblock ID · /blocklist\n\n" +
      "*Статистика:*\n" +
      "/stats · /today · /clearstats",
      { parse_mode: "Markdown" }
    );
  });

  bot.onText(/\/listphrases/, (msg) => {
    if (!isOwner(msg)) return;
    bot.sendMessage(msg.chat.id, `📋 Фразы:\n\n${formatList(listPhrases("randomPhrases"))}`);
  });
  bot.onText(/\/listgossips/, (msg) => {
    if (!isOwner(msg)) return;
    bot.sendMessage(msg.chat.id, `📋 Сплетни:\n\n${formatList(listPhrases("gossips"))}`);
  });
  bot.onText(/\/listsecrets/, (msg) => {
    if (!isOwner(msg)) return;
    bot.sendMessage(msg.chat.id, `📋 Секреты:\n\n${formatList(listPhrases("secrets"))}`);
  });

  bot.onText(/\/addphrase (.+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const text = match?.[1]?.trim(); if (!text) return;
    bot.sendMessage(msg.chat.id, `✅ Фраза добавлена. Всего: ${addPhrase("randomPhrases", text).length}`);
  });
  bot.onText(/\/addgossip (.+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const text = match?.[1]?.trim(); if (!text) return;
    bot.sendMessage(msg.chat.id, `✅ Сплетня добавлена. Всего: ${addPhrase("gossips", text).length}`);
  });
  bot.onText(/\/addsecret (.+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const text = match?.[1]?.trim(); if (!text) return;
    bot.sendMessage(msg.chat.id, `✅ Секрет добавлен. Всего: ${addPhrase("secrets", text).length}`);
  });

  bot.onText(/\/deletephrase (\d+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const r = deletePhrase("randomPhrases", parseInt(match?.[1] ?? "0", 10) - 1);
    bot.sendMessage(msg.chat.id, r ? `🗑 «${r}»` : "❌ Нет такой фразы.");
  });
  bot.onText(/\/deletegossip (\d+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const r = deletePhrase("gossips", parseInt(match?.[1] ?? "0", 10) - 1);
    bot.sendMessage(msg.chat.id, r ? `🗑 «${r}»` : "❌ Нет такой сплетни.");
  });
  bot.onText(/\/deletesecret (\d+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const r = deletePhrase("secrets", parseInt(match?.[1] ?? "0", 10) - 1);
    bot.sendMessage(msg.chat.id, r ? `🗑 «${r}»` : "❌ Нет такого секрета.");
  });

  bot.onText(/\/clearphrases/, (msg) => {
    if (!isOwner(msg)) return;
    clearCategory("randomPhrases"); bot.sendMessage(msg.chat.id, "✅ Все фразы удалены.");
  });
  bot.onText(/\/cleargossips/, (msg) => {
    if (!isOwner(msg)) return;
    clearCategory("gossips"); bot.sendMessage(msg.chat.id, "✅ Все сплетни удалены.");
  });
  bot.onText(/\/clearsecrets/, (msg) => {
    if (!isOwner(msg)) return;
    clearCategory("secrets"); bot.sendMessage(msg.chat.id, "✅ Все секреты удалены.");
  });

  // ── Moderation ────────────────────────────────────────────────────

  function getReplyTarget(msg: Message): number | null {
    const id = msg.reply_to_message?.message_id;
    return id !== undefined ? (replyMap.get(id) ?? null) : null;
  }

  bot.onText(/\/warn/, (msg) => {
    if (!isOwner(msg)) return;
    const chatId = getReplyTarget(msg);
    if (!chatId) { bot.sendMessage(msg.chat.id, "⚠️ Ответь на сообщение пользователя."); return; }
    const count = warnUser(chatId);
    if (count >= MAX_WARNINGS) {
      bot.sendMessage(msg.chat.id, `🚫 Варн ${count}/${MAX_WARNINGS} — *заблокирован*.`, { parse_mode: "Markdown" });
      bot.sendMessage(chatId, "🚫 Ты получил 3 предупреждения и заблокирован.").catch(() => {});
    } else {
      bot.sendMessage(msg.chat.id, `⚠️ Варн выдан. Предупреждений: ${count}/${MAX_WARNINGS}.`);
      bot.sendMessage(chatId, `⚠️ Предупреждение ${count}/${MAX_WARNINGS}.`).catch(() => {});
    }
  });

  bot.onText(/\/unwarn/, (msg) => {
    if (!isOwner(msg)) return;
    const chatId = getReplyTarget(msg);
    if (!chatId) { bot.sendMessage(msg.chat.id, "⚠️ Ответь на сообщение пользователя."); return; }
    const newCount = unwarnUser(chatId);
    if (newCount === null) {
      bot.sendMessage(msg.chat.id, "ℹ️ У пользователя нет предупреждений.");
    } else {
      bot.sendMessage(msg.chat.id, `✅ Предупреждение снято. Осталось: ${newCount}/${MAX_WARNINGS}.`);
      bot.sendMessage(chatId, `✅ Одно предупреждение снято. Осталось: ${newCount}/${MAX_WARNINGS}.`).catch(() => {});
    }
  });

  bot.onText(/\/block/, (msg) => {
    if (!isOwner(msg)) return;
    const chatId = getReplyTarget(msg);
    if (!chatId) { bot.sendMessage(msg.chat.id, "⚠️ Ответь на сообщение пользователя."); return; }
    blockUser(chatId);
    bot.sendMessage(msg.chat.id, `🚫 Заблокирован (ID: ${chatId}).`);
    bot.sendMessage(chatId, "🚫 Ты заблокирован.").catch(() => {});
  });

  bot.onText(/\/unblock (\d+)/, (msg, match) => {
    if (!isOwner(msg)) return;
    const id = parseInt(match?.[1] ?? "", 10);
    if (isNaN(id)) { bot.sendMessage(msg.chat.id, "❌ Укажи корректный ID."); return; }
    const ok = unblockUser(id); clearWarnings(id);
    bot.sendMessage(msg.chat.id, ok ? `✅ Пользователь ${id} разблокирован.` : `❌ ${id} не в списке.`);
  });

  bot.onText(/\/blocklist/, (msg) => {
    if (!isOwner(msg)) return;
    const list = getBlockedList();
    if (list.length === 0) { bot.sendMessage(msg.chat.id, "Список заблокированных пуст."); return; }
    bot.sendMessage(msg.chat.id,
      `🚫 *Заблокированы:*\n\n${list.map((id, i) => `${i + 1}. \`${id}\``).join("\n")}\n\nРазблокировать: /unblock ID`,
      { parse_mode: "Markdown" }
    );
  });

  // ── Stats ─────────────────────────────────────────────────────────

  bot.onText(/\/stats/, (msg) => {
    if (!isOwner(msg)) return;
    setOwnerChatId(msg.chat.id);
    const s = getStats();
    bot.sendMessage(msg.chat.id,
      `📊 *Статистика:*\n\nСегодня: ${s.today}\nВчера: ${s.yesterday}\nВсего: ${s.total}`,
      { parse_mode: "Markdown" }
    );
  });
  bot.onText(/\/today/, (msg) => {
    if (!isOwner(msg)) return;
    const log = getTodayLog();
    if (log.length === 0) { bot.sendMessage(msg.chat.id, "Сегодня сообщений не было."); return; }
    bot.sendMessage(msg.chat.id,
      `📅 *Сегодня (${log.length}):*\n\n${log.map((e, i) => `${i + 1}. [${e.time}] ${e.text}`).join("\n\n")}`,
      { parse_mode: "Markdown" }
    );
  });
  bot.onText(/\/clearstats/, (msg) => {
    if (!isOwner(msg)) return;
    clearStats(); bot.sendMessage(msg.chat.id, "🗑 Статистика сброшена.");
  });

  // ── Message handler ───────────────────────────────────────────────

  bot.on("message", async (msg) => {
    const text = msg.text ?? "";
    if (text.startsWith("/")) return;

    // ── Owner ──
    if (isOwner(msg)) {
      setOwnerChatId(msg.chat.id);

      // Admin: awaiting phrase input
      if (awaitState && awaitState.chatId === msg.chat.id) {
        const { username, cat, menuMsgId } = awaitState;
        awaitState = null;
        const updated = addSpecialPhrase(username, CAT_KEY[cat], text);
        if (!updated) { bot.sendMessage(msg.chat.id, "❌ Пользователь не найден."); return; }
        await bot.editMessageText(renderCategoryText(username, cat), {
          chat_id: msg.chat.id, message_id: menuMsgId,
          reply_markup: categoryMenuKeyboard(username, cat),
        }).catch(() => {});
        bot.sendMessage(msg.chat.id, `✅ Добавлено. Всего: ${updated.length}`);
        return;
      }

      // Owner reply to forwarded anon message
      const replyToId = msg.reply_to_message?.message_id;
      if (replyToId !== undefined) {
        const senderChatId = replyMap.get(replyToId);
        if (senderChatId) {
          try {
            await bot.sendMessage(senderChatId, `💬 Анонимный ответ:\n\n${text}`);
            bot.sendMessage(msg.chat.id, "✅ Ответ отправлен.");
          } catch (err) {
            logger.error({ err }, "Failed to send reply");
            bot.sendMessage(msg.chat.id, "❌ Не удалось отправить ответ.");
          }
        }
      }
      return;
    }

    // ── Non-owner ──

    if (isBlocked(msg.chat.id)) {
      bot.sendMessage(msg.chat.id, "🚫 Ты заблокирован и не можешь отправлять сообщения.");
      return;
    }

    // Gift card awaiting state
    if (giftCardAwait.has(msg.chat.id)) {
      const { menuMsgId, isAnon } = giftCardAwait.get(msg.chat.id)!;
      giftCardAwait.delete(msg.chat.id);

      const senderName = isAnon ? "Аноним" : (msg.from?.username ? `@${msg.from.username}` : "Аноним");
      const cardId = ++cardCounter;
      cardStore.set(cardId, { text, senderName });

      // Confirm to sender
      await bot.editMessageText(
        `💌 *Открытка отправлена!*\n\nТвоя открытка доставлена.`,
        { chat_id: msg.chat.id, message_id: menuMsgId, parse_mode: "Markdown" }
      ).catch(() => {});

      // Notify owner with "Прочитать" button (store in replyMap so owner can reply back)
      const ownerChatId = getOwnerChatId();
      if (ownerChatId) {
        try {
          const notif = await bot.sendMessage(ownerChatId,
            `💌 *Тебе пришла открытка!*\n\nОт: ${senderName}\n\n_Ответь на это сообщение, чтобы написать анонимно._`,
            {
              parse_mode: "Markdown",
              reply_markup: { inline_keyboard: [[{ text: "💌 Прочитать", callback_data: `gread_${cardId}` }]] },
            }
          );
          replyMap.set(notif.message_id, msg.chat.id);
        } catch (err) { logger.error({ err }, "Failed to send card notification"); }
      }
      return;
    }

    // Spam detection
    const now = Date.now();
    const tracker = spamTracker.get(msg.chat.id);
    if (tracker && tracker.lastText === text && now - tracker.lastTime <= SPAM_WINDOW_MS) {
      tracker.count += 1;
      tracker.lastTime = now;
      if (tracker.count > 3) {
        tracker.count = 0;
        const warnCount = warnUser(msg.chat.id);
        const ownerChatId = getOwnerChatId();
        if (ownerChatId) {
          bot.sendMessage(ownerChatId,
            `🤖 *Антиспам:* пользователь отправил одно сообщение более 3-х раз подряд.\n` +
            `⚠️ Автоварн (${warnCount}/${MAX_WARNINGS})${warnCount >= MAX_WARNINGS ? " — *заблокирован*" : ""}.\n\nТекст: «${text}»`,
            { parse_mode: "Markdown" }
          ).catch(() => {});
        }
        bot.sendMessage(msg.chat.id, warnCount >= MAX_WARNINGS
          ? "🚫 Ты заблокирован за спам."
          : `⚠️ Предупреждение за спам ${warnCount}/${MAX_WARNINGS}.`
        );
        return;
      }
    } else {
      spamTracker.set(msg.chat.id, { lastText: text, count: 1, lastTime: now });
    }

    // Forward anonymously
    const senderChatId = msg.chat.id;
    try {
      const forwarded = await bot.sendMessage(`@${OWNER_USERNAME}`, `📨 Анонимное сообщение:\n\n${text}`);
      replyMap.set(forwarded.message_id, senderChatId);
      if (replyMap.size > 500) {
        const first = replyMap.keys().next().value;
        if (first !== undefined) replyMap.delete(first);
      }
      recordMessage(text);
      bot.sendMessage(senderChatId, "Твоё сообщение отправлено анонимно ✉️");
    } catch (err) {
      logger.error({ err }, "Failed to forward anonymous message");
      bot.sendMessage(senderChatId, "Не удалось отправить сообщение. Попробуй позже.");
    }
  });

  bot.on("polling_error", (err) => {
    logger.error({ err }, "Telegram polling error");
  });
}
