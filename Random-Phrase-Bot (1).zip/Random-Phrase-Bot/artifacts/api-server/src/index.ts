import app from "./app";
import { logger } from "./lib/logger";
import { startBot } from "./bot/index.js";

const rawPort = process.env["PORT"] || "3000";
const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.get(["/", "/api"], (_req, res) => {
  res.type("html").send(`<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Telegram Bot</title>
    <style>
      body {
        margin: 0;
        min-height: 100vh;
        display: grid;
        place-items: center;
        font-family: system-ui, sans-serif;
        color: #172033;
        background: #f4f7fb;
      }
      main {
        padding: 2rem 2.5rem;
        text-align: center;
        background: white;
        border: 1px solid #dce3ee;
        border-radius: 1rem;
        box-shadow: 0 12px 30px rgb(23 32 51 / 10%);
      }
      h1 { margin: 0 0 0.5rem; }
      p { margin: 0; color: #5b667a; }
    </style>
  </head>
  <body>
    <main>
      <h1>Telegram-бот работает</h1>
      <p>Сервис запущен и готов принимать сообщения.</p>
    </main>
  </body>
</html>`);
});

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});

startBot();
